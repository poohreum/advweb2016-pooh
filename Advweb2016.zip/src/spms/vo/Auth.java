package spms.vo;

public class Auth {
	protected int 		no;
	protected String	id;
	protected String 	password;
	protected String 	name;
	protected String 	email;
	protected double myLat;
	protected double myLon;
	
	public int getNo() {
		return no;
	}
	public Auth setNo(int no) {
		this.no = no;
		return this;
	}
	public String getId() {
		return id;
	}
	public Auth setId(String auth_id) {
		this.id = auth_id;
		return this;
	}
	public String getPassword() {
		return password;
	}
	public Auth setPassword(String password) {
		this.password = password;
		return this;
	}
	public String getName() {
		return name;
	}
	public Auth setName(String name) {
		this.name = name;
		return this;
	}
	public String getEmail() {
		return email;
	}
	public Auth setEmail(String email) {
		this.email = email;
		return this;
	}
	public double getMyLat() {
		return myLat;
	}
	public Auth setMyLat(double myLat) {
		this.myLat = myLat;
		return this;
	}
	public double getMyLon() {
		return myLon;
	}
	public Auth setMyLon(double myLon) {
		this.myLon = myLon;
		return this;
	}
	/*
	public String getMyLat() {
		return myLat;
	}
	public Auth setMyLat(String myLat) {
		this.myLat = myLat;
		return this;
	}
	public String getMyLon() {
		return myLon;
	}
	public Auth setMyLon(String myLon) {
		this.myLon = myLon;
		return this;
	}	*/
}
