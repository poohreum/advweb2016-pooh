package spms.vo;

public class Quiz {
	protected int 		no;
	protected String	image;//�н�����
	protected String 	content;//�н�����
	protected String 	quiz1;//������
	protected String 	quiz2;
	protected String 	quiz3;
	protected String 	answer1;//����ڿ��� ���� ��
	protected String 	answer2;
	protected String 	answer3;
	protected String 	ox1;//���俩��
	protected String 	ox2;
	protected String	ox3;
	
	public int getNo() {
		return no;
	}
	public Quiz setNo(int no) {
		this.no = no;
		return this;
	}
	public String getImage() {
		return image;
	}
	public Quiz setImage(String image) {
		this.image = image;
		return this;
	}
	public String getContent() {
		return content;
	}
	public Quiz setContent(String content) {
		this.content = content;
		return this;
	}
	public String getQuiz1() {
		return quiz1;
	}
	public Quiz setQuiz1(String quiz1) {
		this.quiz1 = quiz1;
		return this;
	}
	public String getQuiz2() {
		return quiz2;
	}
	public Quiz setQuiz2(String quiz2) {
		this.quiz2 = quiz2;
		return this;
	}
	public String getQuiz3() {
		return quiz3;
	}
	public Quiz setQuiz3(String quiz3) {
		this.quiz3 = quiz3;
		return this;
	}
	public String getAnswer1() {
		return answer1;
	}
	public Quiz setAnswer1(String answer1) {
		this.answer1 = answer1;
		return this;
	}
	public String getAnswer2() {
		return answer2;
	}
	public Quiz setAnswer2(String answer2) {
		this.answer2 = answer2;
		return this;
	}
	public String getAnswer3() {
		return answer3;
	}
	public Quiz setAnswer3(String answer3) {
		this.answer3 = answer3;
		return this;
	}	
	public String getOx1() {
		return ox1;
	}
	public Quiz setOx1(String ox1) {
		this.ox1 = ox1;
		return this;
	}
	public String getOx2() {
		return ox2;
	}
	public Quiz setOx2(String ox2) {
		this.ox2 = ox2;
		return this;
	}
	public String getOx3() {
		return ox3;
	}
	public Quiz setOx3(String ox3) {
		this.ox3 = ox3;
		return this;
	}

}
