package spms.controls;

import java.util.Map;

import javax.servlet.http.HttpSession;

import spms.dao.Dao;
import spms.vo.Auth;

public class SearchAuthController implements Controller {
  Dao authDao;
  
  public SearchAuthController setDao(Dao Dao) {
    this.authDao = Dao;
    return this;
  }
  
  @Override
  public String execute(Map<String, Object> model) throws Exception {
    if (model.get("searchAuth") == null) { 
      return "/auth/SearchAuth.jsp";
      
    } else {
      Auth searchauth = (Auth)model.get("searchAuth");
      Auth auth = authDao.search(searchauth);
      model.put("search", auth);
      
      return "/auth/SearchAuth.jsp";
    }
  }
}
