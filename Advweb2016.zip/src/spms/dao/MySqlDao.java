package spms.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import spms.vo.Auth;
//Dao �������̽��� �����ϱ� ���� implements Dao�� �Ѵ�.
public class MySqlDao implements Dao {
  DataSource ds;

  public void setDataSource(DataSource ds) {
    this.ds = ds;
  }

  public Auth exist(String auth_id, String password) throws Exception {
    Connection connection = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;

    try {
      connection = ds.getConnection();
      stmt = connection.prepareStatement(
          "SELECT no, auth_id, name, email FROM auth"
              + " WHERE auth_id=? AND password=?");
      stmt.setString(1, auth_id);
      stmt.setString(2, password);
      rs = stmt.executeQuery();
      if (rs.next()) {
        return new Auth()
          .setNo(rs.getInt("no"))
          .setId(rs.getString("auth_id"))
          .setName(rs.getString("name"))
          .setEmail(rs.getString("email"));
      } else {
        return null;
      }
    } catch (Exception e) {
      throw e;

    } finally {
      try {if (rs != null) rs.close();} catch (Exception e) {}
      try {if (stmt != null) stmt.close();} catch (Exception e) {}
      try {if (connection != null) connection.close();} catch(Exception e) {}
    }
  }

	@Override
  public int insert(Auth auth) throws Exception {
	// TODO Auto-generated method stub
		Connection connection = null;
	    PreparedStatement stmt = null;

	    try {
	      connection = ds.getConnection();
	      stmt = connection.prepareStatement(
	          "INSERT INTO auth(auth_id,password,name,email)"
	              + " VALUES (?,?,?,?)");
	      stmt.setString(1, auth.getId());
	      stmt.setString(2, auth.getPassword());
	      stmt.setString(3, auth.getName());
	      stmt.setString(4, auth.getEmail());
	      return stmt.executeUpdate();

	    } catch (Exception e) {
	        //throw e;
	    	throw new Exception("insert����.");

	    } finally {
	        try {if (stmt != null) stmt.close();} catch(Exception e) {}
	        try {if (connection != null) connection.close();} catch(Exception e) {}
	    }
  }
  public int idCheck(Auth auth) throws Exception{
     	Connection connection = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
		try{
	      connection = ds.getConnection();
		  stmt = connection.prepareStatement(
		      "SELECT auth_id FROM auth"
		          + " WHERE auth_id=? or email=?;");
		  stmt.setString(1, auth.getId());
		  stmt.setString(2, auth.getEmail());
		  rs = stmt.executeQuery();
		  if(rs.next()){
			if(rs.getString("auth_id").equals(auth.getId())){
				return 11;
			} else{
				return 22;
			}
		  } else {
			  return 33;
		  }
		} catch (Exception e) {
		      //throw e;
		      throw new Exception("idCheck����.");
	    } finally{
		    try {if (rs != null) rs.close();} catch (Exception e) {}
		    try {if (stmt != null) stmt.close();} catch (Exception e) {}
		    try {if (connection != null) connection.close();} catch(Exception e) {}
		}
  }
  public Auth search(Auth auth) throws Exception{
   	Connection connection = null;
	    PreparedStatement stmt = null;
	    ResultSet rs = null;
		try{
	      connection = ds.getConnection();
		  stmt = connection.prepareStatement(
		      "SELECT auth_id, password FROM auth"
		          + " WHERE name=? and email=?;");
		  stmt.setString(1, auth.getName());
		  stmt.setString(2, auth.getEmail());
		  rs = stmt.executeQuery();
		  if(rs.next()){
		    return new Auth()
	          .setId(rs.getString("auth_id"))
	     	  .setPassword(rs.getString("password"));
		  } else {
			  throw new Exception("search ����.");
		  }
		} catch (Exception e) {
		      throw e;
	    } finally{
		    try {if (rs != null) rs.close();} catch (Exception e) {}
		    try {if (stmt != null) stmt.close();} catch (Exception e) {}
		    try {if (connection != null) connection.close();} catch(Exception e) {}
		}
}
public Auth searchup(Auth auth) throws Exception{
	   	Connection connection = null;
		    PreparedStatement stmt = null;
		    ResultSet rs = null;
			try{
		      connection = ds.getConnection();
			  stmt = connection.prepareStatement(
			      "SELECT auth_id, password, name, email FROM auth"
			          + " WHERE name=? and password=? and no=?;");//����
			  stmt.setString(1, auth.getName());
			  stmt.setString(2, auth.getPassword());
			  stmt.setInt(3, auth.getNo());
			  rs = stmt.executeQuery();
			  if(rs.next()){
			    return new Auth()
		          .setId(rs.getString("auth_id"))
		     	  .setPassword(rs.getString("password"))
		     	  .setName(rs.getString("name"))
		     	  .setEmail(rs.getString("email"));
			  } else {
				  return null;
			  }
			} catch (Exception e) {
			      throw e;
		    } finally{
			    try {if (rs != null) rs.close();} catch (Exception e) {}
			    try {if (stmt != null) stmt.close();} catch (Exception e) {}
			    try {if (connection != null) connection.close();} catch(Exception e) {}
			}
}

  public int update(Auth auth) throws Exception { 
    Connection connection = null;
    PreparedStatement stmt = null;
    try {
      connection = ds.getConnection();
      stmt = connection.prepareStatement(
          "UPDATE auth SET password=?"
              + " WHERE email=?");
      stmt.setString(1, auth.getPassword());
      stmt.setString(2, auth.getEmail());
      return stmt.executeUpdate();

    } catch (Exception e) {
    	throw new Exception("update ����.");

    } finally {
      try {if (stmt != null) stmt.close();} catch(Exception e) {}
      try {if (connection != null) connection.close();} catch(Exception e) {}
    }
  }
  public int delete(Auth auth) throws Exception { 
	    Connection connection = null;
	    PreparedStatement stmt = null;
	    try {
	      connection = ds.getConnection();
	      stmt = connection.prepareStatement(
	          "DELETE FROM auth WHERE NO=? and PASSWORD=?");
	      stmt.setInt(1, auth.getNo());
	      stmt.setString(2, auth.getPassword());

	      return stmt.executeUpdate();

	    } catch (Exception e) {
	    	throw new Exception("delete ����.");

	    } finally {
	      try {if (stmt != null) stmt.close();} catch(Exception e) {}
	      try {if (connection != null) connection.close();} catch(Exception e) {}
	    }
	  }
}
